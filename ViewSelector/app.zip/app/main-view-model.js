import { Observable } from '@nativescript/core'



export function createViewModel() {
  const viewModel = new Observable()

  return viewModel
}

