import { createViewModel } from './main-view-model';
import { ViewSelector } from './SelectorPlugin';

export function onNavigatingTo(args) {
  const page = args.object

  let vs1=page.getViewById('vs1')
  let vs2=page.getViewById('vs2')
  
  vs1.selector[0].labels='(Click), to view id, btn1'
  vs1.selector[1].labels='(Click), to view id, btn2'
  vs1.selector[2].labels='(Click), to view id, btn3'
  
  vs2.Vertical()

  vs2.selectorBox=true
  
  vs2.selector[0].labels='Tap for, a, p'
  vs2.selector[1].labels='Tap for, a, p'
  vs2.selector[2].labels='Tap for, w, p'
   
  vs2.selector[0].label[1].fontSize='54'
  vs2.selector[0].label[1].color='red'
  
  vs2.selector[1].label[1].fontSize='54'
  vs2.selector[1].label[1].color='green'
  
  vs2.selector[2].label[1].fontSize='54'
  vs2.selector[2].label[1].color='purple'

  vs2.BindRichText(vs2.selector[0].label[1],'fab:\uf179')
  vs2.BindRichText(vs2.selector[0].label[2],'far:\uf25d',' products.')

  vs2.BindRichText(vs2.selector[1].label[1],'fab:\uf17b')
  vs2.BindRichText(vs2.selector[1].label[2],'far:\uf25d',' products.')
  
  vs2.BindRichText(vs2.selector[2].label[1],'fab:\uf17a')
  vs2.BindRichText(vs2.selector[2].label[2],'far:\uf25d',' products.')

  page.bindingContext = createViewModel()
  
}
